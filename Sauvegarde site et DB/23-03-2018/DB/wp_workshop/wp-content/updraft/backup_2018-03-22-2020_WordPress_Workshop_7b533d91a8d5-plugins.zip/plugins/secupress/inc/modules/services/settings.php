<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'services' );
$this->load_plugin_settings( 'support' );
