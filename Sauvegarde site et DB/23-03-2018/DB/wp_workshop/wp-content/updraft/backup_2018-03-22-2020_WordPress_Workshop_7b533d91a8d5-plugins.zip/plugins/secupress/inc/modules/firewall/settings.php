<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'bbq-headers' );
$this->load_plugin_settings( 'bbq-url-content' );
$this->load_plugin_settings( 'bruteforce' );
$this->load_plugin_settings( 'geoip-system' );
