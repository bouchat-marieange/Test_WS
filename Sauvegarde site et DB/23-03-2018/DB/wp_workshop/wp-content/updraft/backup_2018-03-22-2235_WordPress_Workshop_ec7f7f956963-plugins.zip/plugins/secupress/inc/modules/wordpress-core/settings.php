<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'auto-update' );
$this->load_plugin_settings( 'wp-config' );
